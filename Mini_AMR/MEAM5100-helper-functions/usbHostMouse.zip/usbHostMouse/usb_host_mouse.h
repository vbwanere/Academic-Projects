/*
 * USB houst mouse
 * temporary ESP32 arduino hack for ESP32 as USB host to read in usb mouse
 * builds off of IDF 5 hid_host_example.c in examples> peripheral> usb > host > hid
 * July 2023
 * Mark Yim, University of Pennsylvania
 * Copyright 2023 all rights reserved
 */

#ifndef USBHOSTMOUSE_h
#define USBHOSTMOUSE_h

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/event_groups.h"
#include "usb/usb_host.h"

#include "hid_host.h"
#include "hid_usage_mouse.h"


/**
 * @brief Application Event from USB Host driver
 *
 */
typedef enum {
  HOST_NO_CLIENT = 0x1,
  HOST_ALL_FREE = 0x2,
  DEVICE_CONNECTED = 0x4,
  DEVICE_DISCONNECTED = 0x8,
  DEVICE_ADDRESS_MASK = 0xFF0,
} app_event_t;

typedef enum{
  MOUSE_OK = 0x00,
  MOUSE_MISSING = 0x01,
  MOUSE_NOUSBHOST = 0x02,
  MOUSE_NOUSBHID = 0x04,
  MOUSE_NOCOMMS = 0x08,
} mouse_install_t;

#define USB_EVENTS_TO_WAIT (DEVICE_CONNECTED | DEVICE_ADDRESS_MASK | DEVICE_DISCONNECTED)

class usb_host_mouse
{
 
public:
  int x_pos() ;
  int y_pos() ;
  uint8_t button1() ;
  uint8_t button2() ;

  usb_host_mouse(); // default constructor
  int begin();

  EventBits_t check_connection_events();

};  


#endif