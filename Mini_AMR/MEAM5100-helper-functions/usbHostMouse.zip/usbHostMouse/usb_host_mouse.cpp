/*
 * USB houst mouse
 * temporary ESP32 arduino hack for ESP32 as USB host to read in usb mouse
 * builds off of IDF 5 hid_host_example.c in examples> peripheral> usb > host > hid
 * July 2023
 * Mark Yim, University of Pennsylvania
 * Copyright 2023 all rights reserved
 */

#include "usb_host_mouse.h"

int m_x_pos=0;
int m_y_pos=0;
uint8_t m_button1 = false;
uint8_t m_button2 = false;

static EventGroupHandle_t m_usb_flags;
static int m_hid_device_connected;
static hid_host_interface_handle_t m_mouse_handle;

usb_host_mouse::usb_host_mouse() {
}

int usb_host_mouse::x_pos(){
  return m_x_pos;
}

int usb_host_mouse::y_pos(){
  return m_y_pos;
}

uint8_t usb_host_mouse::button1(){
  return m_button1;
}

uint8_t usb_host_mouse::button2(){
  return m_button2;
}

/**
 * @brief USB HID Host Mouse Interface report callback handler
 *
 * @param[in] data    Pointer to input report data buffer
 * @param[in] length  Length of input report data buffer
 */
static void hid_host_mouse_report_callback(const uint8_t *const data, const int length) {
  hid_mouse_input_report_boot_t *mouse_report = (hid_mouse_input_report_boot_t *)data;

  if (length < sizeof(hid_mouse_input_report_boot_t)) {
    return;
  }
  // Calculate absolute position from displacement
  m_x_pos += mouse_report->x_displacement;
  m_y_pos += mouse_report->y_displacement;
  m_button1 = mouse_report->buttons.button1;
  m_button2 = mouse_report->buttons.button2;
}

/**
 * @brief USB HID Host event callback. Handle such event as device connection and removing
 *
 * @param[in] event  HID device event
 * @param[in] arg    Pointer to arguments, does not used
 */
static void hid_host_event_callback(const hid_host_event_t *event, void *arg) {
  if (event->event == hid_host_event_t::HID_DEVICE_CONNECTED) {  // note C++ difference from C for enum
    // Obtained USB device address is placed after application events
    xEventGroupSetBits(m_usb_flags, DEVICE_CONNECTED | (event->device.address << 4));
  } else if (event->event == hid_host_event_t::HID_DEVICE_DISCONNECTED) {
    xEventGroupSetBits(m_usb_flags, DEVICE_DISCONNECTED);
  }
}

/**
 * @brief USB HID Host interface callback for mouse only
 *
 * @param[in] event  HID interface event
 * @param[in] arg    Pointer to arguments, does not used
 */
static void hid_host_interface_event_callback(const hid_host_interface_event_t *event, void *arg) {
  //printf("HID event %d\n", event->event);
  switch (event->event) {
    case HID_DEVICE_INTERFACE_INIT:
      if (event->interface.proto == HID_PROTOCOL_MOUSE) {
        const hid_host_interface_config_t hid_mouse_config = {
          .proto = HID_PROTOCOL_MOUSE,
          .callback = hid_host_mouse_report_callback,
        };
        hid_host_claim_interface(&hid_mouse_config, &m_mouse_handle);
      }
     // else printf("HID protocol not for mouse\n");

      break;
    case HID_DEVICE_INTERFACE_TRANSFER_ERROR:
      printf("Interface number %d, transfer error\n",
             event->interface.num);
      break;

    case HID_DEVICE_INTERFACE_CLAIM:
    case HID_DEVICE_INTERFACE_RELEASE:
   //   printf("CLAIM or RELEASE\n");
      // ... do nothing here for now
      break;

    default:
      printf("%s Unhandled event %X, Interface number %d\n",
             __FUNCTION__,
             event->event,
             event->interface.num);
      break;
  }
}

/**
 * @brief Handle common USB host library events
 *   
 * @param[in] args  Pointer to arguments, not used
 */
static void handle_usb_events(void *args) {
  while (1) {
    uint32_t event_flags;
    usb_host_lib_handle_events(portMAX_DELAY, &event_flags);

    // Release devices once all clients has deregistered
    if (event_flags & USB_HOST_LIB_EVENT_FLAGS_NO_CLIENTS) {
      usb_host_device_free_all();
      xEventGroupSetBits(m_usb_flags, HOST_NO_CLIENT);
    }
    // Give ready_to_uninstall_usb semaphore to indicate that USB Host library
    // can be deinitialized, and terminate this task.
    if (event_flags & USB_HOST_LIB_EVENT_FLAGS_ALL_FREE) {
      xEventGroupSetBits(m_usb_flags, HOST_ALL_FREE);
    }
  }

  vTaskDelete(NULL);
}

EventBits_t usb_host_mouse::check_connection_events() {
  static hid_host_device_handle_t hid_device;
  EventBits_t event = xEventGroupWaitBits(m_usb_flags, USB_EVENTS_TO_WAIT, pdTRUE, pdFALSE, pdMS_TO_TICKS(500));

  if (event & DEVICE_CONNECTED) {
  //  printf("mouse connected 0x%x mask 0x%x\n",event, DEVICE_CONNECTED);
    xEventGroupClearBits(m_usb_flags, DEVICE_CONNECTED);
    m_hid_device_connected = true;
  }

  if (event & DEVICE_ADDRESS_MASK) {
  //  printf("event & mask %x, event %x\n", DEVICE_ADDRESS_MASK, event);
    xEventGroupClearBits(m_usb_flags, DEVICE_ADDRESS_MASK);
    const hid_host_device_config_t hid_host_device_config = {
      .dev_addr = (uint8_t)((event & DEVICE_ADDRESS_MASK) >> 4),
      .iface_event_cb = hid_host_interface_event_callback,
      .iface_event_arg = NULL,
    };
    hid_host_install_device(&hid_host_device_config, &hid_device);
  }

  if (event & DEVICE_DISCONNECTED) {
    //printf("disconnected, %d\n", event);
    xEventGroupClearBits(m_usb_flags, DEVICE_DISCONNECTED);
    hid_host_release_interface(m_mouse_handle);
    hid_host_uninstall_device(hid_device);
    m_hid_device_connected = false;
  }
  return event;
}

int usb_host_mouse::begin() {
  uint mouse_errs= MOUSE_OK;
  BaseType_t task_created;
  TaskHandle_t usb_events_task_handle;

  m_usb_flags = xEventGroupCreate();
  assert(m_usb_flags);

  const usb_host_config_t host_config = {
    .skip_phy_setup = false,
    .intr_flags = ESP_INTR_FLAG_LEVEL1
  };

  if (usb_host_install(&host_config)!= 0)
    mouse_errs |= MOUSE_NOUSBHOST;

  task_created = xTaskCreate(handle_usb_events, "usb_events\n", 4096, NULL, 2, &usb_events_task_handle);
  assert(task_created);

  // hid host driver config
  const hid_host_driver_config_t hid_host_config = {
    .create_background_task = true,
    .task_priority = 5,
    .stack_size = 4096,
    .core_id = 0,
    .callback = hid_host_event_callback,
    .callback_arg = NULL
  };

  if (hid_host_install(&hid_host_config)!= 0)
    mouse_errs |= MOUSE_NOUSBHOST;
  
  //vTaskDelay(1 / portTICK_RATE_MS); // same as Arduino delay();
  if (usb_host_mouse::check_connection_events() == 0) 
    mouse_errs |= MOUSE_NOCOMMS;

  if (!m_hid_device_connected)
    mouse_errs |= MOUSE_MISSING;
  
  return mouse_errs;
}
